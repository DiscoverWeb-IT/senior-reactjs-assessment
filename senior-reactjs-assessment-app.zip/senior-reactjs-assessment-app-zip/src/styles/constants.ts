// APP TEXT
export const APP_TITLE = "Senior ReactJS Assessment App";
export const APP_DESCRIPTION =
  "Senior ReactJS Assessment App";
// APP THEME
export const DARK_MODE_THEME = "dark";
